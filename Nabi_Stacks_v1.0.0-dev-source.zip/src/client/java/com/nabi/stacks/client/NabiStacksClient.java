package com.nabi.stacks.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.nabi.stacks.client.gui.NabiStacksConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class NabiStacksClient implements ClientModInitializer {
    private KeyMapping openConfig;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("nabi_stacks", "main")
        );

        openConfig = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.nabi_stacks.open_config",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_F8,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfig.consumeClick()) {
                open(client);
            }
        });
    }

    private static void open(Minecraft client) {
        client.setScreen(new NabiStacksConfigScreen(client.screen));
    }
}
