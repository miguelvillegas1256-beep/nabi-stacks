package com.nabi.stacks.client.gui;

import com.nabi.stacks.config.StackConfig;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class NabiStacksConfigScreen extends Screen {
    private final Screen parent;
    private EditBox playerMax;
    private EditBox storageMax;
    private boolean unique;
    private boolean splitDamageable;
    private Button uniqueButton;
    private Button splitButton;

    public NabiStacksConfigScreen(Screen parent) {
        super(Component.literal("Nabi Stacks"));
        this.parent = parent;
        this.unique = StackConfig.get().stackUniqueItems;
        this.splitDamageable = StackConfig.get().splitDamageableOnUse;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 80;

        playerMax = new EditBox(this.font, cx - 55, y, 110, 20, Component.literal("Player max"));
        playerMax.setValue(Integer.toString(StackConfig.get().playerMaxStack));
        playerMax.setFilter(NabiStacksConfigScreen::digitsOnly);
        addRenderableWidget(playerMax);

        storageMax = new EditBox(this.font, cx - 55, y + 34, 110, 20, Component.literal("Storage max"));
        storageMax.setValue(Integer.toString(StackConfig.get().storageMaxStack));
        storageMax.setFilter(NabiStacksConfigScreen::digitsOnly);
        addRenderableWidget(storageMax);

        uniqueButton = addRenderableWidget(Button.builder(uniqueLabel(), b -> {
            unique = !unique;
            b.setMessage(uniqueLabel());
        }).bounds(cx - 100, y + 68, 200, 20).build());

        splitButton = addRenderableWidget(Button.builder(splitLabel(), b -> {
            splitDamageable = !splitDamageable;
            b.setMessage(splitLabel());
        }).bounds(cx - 100, y + 94, 200, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Guardar"), b -> saveAndClose())
                .bounds(cx - 100, y + 128, 96, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancelar"), b -> onClose())
                .bounds(cx + 4, y + 128, 96, 20).build());
    }

    private Component uniqueLabel() {
        return Component.literal("Objetos únicos: " + (unique ? "ON" : "OFF"));
    }

    private Component splitLabel() {
        return Component.literal("Separar herramienta al usar: " + (splitDamageable ? "ON" : "OFF"));
    }

    private void saveAndClose() {
        int player = parse(playerMax.getValue(), StackConfig.get().playerMaxStack);
        int storage = parse(storageMax.getValue(), StackConfig.get().storageMaxStack);
        StackConfig.apply(player, storage, unique, splitDamageable);
        onClose();
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }

    private static boolean digitsOnly(String value) {
        return value.isEmpty() || value.chars().allMatch(Character::isDigit);
    }

    private static int parse(String value, int fallback) {
        try { return StackConfig.clamp(Integer.parseInt(value)); }
        catch (Exception e) { return fallback; }
    }
}
