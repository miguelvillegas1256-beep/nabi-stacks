package com.nabi.stacks.logic;

import com.nabi.stacks.config.StackConfig;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.ItemStack;

public final class StackRules {
    private StackRules() { }

    public static int maxForContainer(Container container) {
        if (container instanceof Inventory) {
            return StackConfig.get().playerMaxStack;
        }
        return StackConfig.get().storageMaxStack;
    }

    public static int maxForItemInstance(ItemInstance item) {
        int vanilla = item.getOrDefault(DataComponents.MAX_STACK_SIZE, 1);
        if (!(item instanceof ItemStack stack)) {
            return vanilla;
        }

        if (!StackConfig.get().stackUniqueItems && vanilla <= 1) {
            return vanilla;
        }

        // Items still only merge when ItemStack.isSameItemSameComponents is true.
        // That comparison includes damage, enchantments, custom names and other components.
        return Math.max(vanilla, StackConfig.globalMax());
    }

    public static boolean shouldTreatAsStackable(ItemStack stack) {
        if (stack.isEmpty()) return false;
        int vanilla = stack.getOrDefault(DataComponents.MAX_STACK_SIZE, 1);
        return vanilla > 1 || StackConfig.get().stackUniqueItems;
    }
}
