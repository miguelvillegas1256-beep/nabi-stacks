package com.nabi.stacks.config;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class StackConfig {
    public static final int HARD_MAX = 500;
    public static final int MIN = 1;
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("nabi-stacks.properties");
    private static StackConfig INSTANCE = defaults();

    public int playerMaxStack = 500;
    public int storageMaxStack = 500;
    public boolean stackUniqueItems = true;
    public boolean splitDamageableOnUse = true;

    public static StackConfig get() { return INSTANCE; }

    public static StackConfig defaults() { return new StackConfig(); }

    public static void load() {
        StackConfig cfg = defaults();
        if (Files.exists(PATH)) {
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(PATH)) {
                p.load(in);
                cfg.playerMaxStack = clamp(parseInt(p.getProperty("playerMaxStack"), 500));
                cfg.storageMaxStack = clamp(parseInt(p.getProperty("storageMaxStack"), 500));
                cfg.stackUniqueItems = Boolean.parseBoolean(p.getProperty("stackUniqueItems", "true"));
                cfg.splitDamageableOnUse = Boolean.parseBoolean(p.getProperty("splitDamageableOnUse", "true"));
            } catch (IOException ignored) { }
        }
        INSTANCE = cfg;
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Properties p = new Properties();
            p.setProperty("playerMaxStack", Integer.toString(INSTANCE.playerMaxStack));
            p.setProperty("storageMaxStack", Integer.toString(INSTANCE.storageMaxStack));
            p.setProperty("stackUniqueItems", Boolean.toString(INSTANCE.stackUniqueItems));
            p.setProperty("splitDamageableOnUse", Boolean.toString(INSTANCE.splitDamageableOnUse));
            try (OutputStream out = Files.newOutputStream(PATH)) {
                p.store(out, "Nabi Stacks v1 configuration");
            }
        } catch (IOException ignored) { }
    }

    public static void apply(int player, int storage, boolean unique, boolean splitDamageable) {
        INSTANCE.playerMaxStack = clamp(player);
        INSTANCE.storageMaxStack = clamp(storage);
        INSTANCE.stackUniqueItems = unique;
        INSTANCE.splitDamageableOnUse = splitDamageable;
        save();
    }

    public static int globalMax() {
        return Math.max(INSTANCE.playerMaxStack, INSTANCE.storageMaxStack);
    }

    public static int clamp(int value) {
        return Math.max(MIN, Math.min(HARD_MAX, value));
    }

    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); }
        catch (Exception e) { return fallback; }
    }
}
