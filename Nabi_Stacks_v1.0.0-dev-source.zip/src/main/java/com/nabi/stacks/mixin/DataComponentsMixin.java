package com.nabi.stacks.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import net.minecraft.core.component.DataComponents;

@Mixin(DataComponents.class)
public abstract class DataComponentsMixin {
    @ModifyConstant(method = "<clinit>", constant = @Constant(intValue = 99), require = 1)
    private static int nabi$raiseMaxStackComponentCodec(int original) {
        return 500;
    }
}
