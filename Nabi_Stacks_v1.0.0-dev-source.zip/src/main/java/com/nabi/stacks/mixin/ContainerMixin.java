package com.nabi.stacks.mixin;

import com.nabi.stacks.logic.StackRules;
import net.minecraft.world.Container;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Container.class)
public interface ContainerMixin {
    @Inject(method = "getMaxStackSize()I", at = @At("HEAD"), cancellable = true)
    private void nabi$containerMax(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(StackRules.maxForContainer((Container) this));
    }
}
