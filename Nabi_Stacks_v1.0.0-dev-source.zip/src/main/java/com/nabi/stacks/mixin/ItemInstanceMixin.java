package com.nabi.stacks.mixin;

import com.nabi.stacks.logic.StackRules;
import net.minecraft.world.item.ItemInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemInstance.class)
public interface ItemInstanceMixin {
    @Inject(method = "getMaxStackSize()I", at = @At("HEAD"), cancellable = true)
    private void nabi$itemMax(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(StackRules.maxForItemInstance((ItemInstance) this));
    }
}
