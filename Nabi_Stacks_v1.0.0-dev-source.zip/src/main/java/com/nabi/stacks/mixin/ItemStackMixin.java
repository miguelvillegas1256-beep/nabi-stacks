package com.nabi.stacks.mixin;

import com.nabi.stacks.config.StackConfig;
import com.nabi.stacks.logic.StackRules;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Consumer;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @ModifyConstant(method = "<clinit>", constant = @Constant(intValue = 99), require = 1)
    private static int nabi$raisePersistentStackCodec(int original) {
        return 500;
    }

    @Inject(method = "isStackable()Z", at = @At("HEAD"), cancellable = true)
    private void nabi$allowIdenticalUniqueStacks(CallbackInfoReturnable<Boolean> cir) {
        ItemStack self = (ItemStack) (Object) this;
        if (StackConfig.get().stackUniqueItems && StackRules.shouldTreatAsStackable(self)) {
            cir.setReturnValue(self.getMaxStackSize() > 1);
        }
    }

    @Inject(
        method = "hurtAndBreak(ILnet/minecraft/server/level/ServerLevel;Lnet/minecraft/server/level/ServerPlayer;Ljava/util/function/Consumer;)V",
        at = @At("HEAD")
    )
    private void nabi$splitDamageableBeforeUse(int amount, ServerLevel level, ServerPlayer player,
                                               Consumer<ItemStack> onBreak, CallbackInfo ci) {
        if (!StackConfig.get().stackUniqueItems || !StackConfig.get().splitDamageableOnUse || player == null) {
            return;
        }

        ItemStack self = (ItemStack) (Object) this;
        if (!self.isDamageableItem() || self.getCount() <= 1) {
            return;
        }

        int oldCount = self.getCount();
        ItemStack remainder = self.copyWithCount(oldCount - 1);
        self.setCount(1);

        Inventory inventory = player.getInventory();
        int free = inventory.getFreeSlot();
        if (free >= 0) {
            inventory.setItem(free, remainder);
        } else {
            player.drop(remainder, false);
        }
    }
}
