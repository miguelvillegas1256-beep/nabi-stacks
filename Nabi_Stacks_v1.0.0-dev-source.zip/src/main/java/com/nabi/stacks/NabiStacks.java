package com.nabi.stacks;

import com.nabi.stacks.config.StackConfig;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NabiStacks implements ModInitializer {
    public static final String MOD_ID = "nabi_stacks";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        StackConfig.load();
        LOGGER.info("Nabi Stacks initialized: player={}, storage={}, unique={}",
                StackConfig.get().playerMaxStack,
                StackConfig.get().storageMaxStack,
                StackConfig.get().stackUniqueItems);
    }
}
