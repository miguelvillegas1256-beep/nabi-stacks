# Nabi Stacks v1.0.0-dev

Fabric mod prototype for Minecraft Java 26.3.

## Target
- Minecraft Java 26.3
- Fabric Loader 0.19.5
- Fabric API 0.161.0+26.3
- Java 25

## v1 goals implemented in source
- Up to 500 items per stack.
- Separate configurable limits for player inventory and storage/container inventories.
- F8 configuration screen.
- Config file: `config/nabi-stacks.properties`.
- Raises vanilla 99-count persistence codec ceiling to 500.
- Raises `max_stack_size` component codec ceiling to 500.
- Optional stacking for normally unstackable items.
- Identical unique items only merge when Minecraft considers item + components identical; damage, enchantments and custom components therefore remain part of stack identity.
- Damageable stack safeguard: when durability is consumed by a player and the held stack contains more than one item, one item is separated for damage and the remaining identical items are placed in a free inventory slot (or dropped if full).

## Important v1-dev limitations
This is a development build/source milestone, not a release JAR yet. The difficult part of 500 stacks in 26.3 is not the UI: vanilla persistence codecs cap item counts at 99, so the mixins in this project patch those limits as well.

The two-context limit (player vs storage) is implemented at `Container#getMaxStackSize()`. Specialized slots such as armor slots can still enforce their own smaller limits.

Unique-item stacking is intentionally component-exact. Two swords with different damage values, enchantments, names, trims or other data will not merge because `ItemStack.isSameItemSameComponents` will not consider them equal.

Damageable stacked items need extensive gameplay testing (tools, weapons, armor, Elytra, modded equipment). v1 includes the first split-on-durability safeguard, but this needs testing before calling it production-safe.

Dedicated multiplayer config sync is not implemented yet. In singleplayer/integrated server, client and server use the same config directory/process. For dedicated servers, edit the server's `config/nabi-stacks.properties` for now.

## Build
Use JDK 25, then from the project root:

```bash
./gradlew build
```

If no Gradle wrapper is present, import the project in IntelliJ with JDK 25 and create/update a Gradle 9.6+ wrapper, or copy the wrapper files from Fabric's 26.3 example mod.

Output JAR will be under `build/libs/`.

## Test checklist
1. Cobblestone pickup merges above 99 and up to 500.
2. Save world, quit completely, reopen: x500 persists.
3. Chest/barrel/shulker/Ender Chest storage accepts configured storage limit.
4. Set player=100/storage=500 and verify player slots stop at 100 while chest slots continue higher.
5. Stack two identical full-durability tools.
6. Stack two identical damaged tools with the exact same damage value.
7. Verify tools with different damage values do not merge.
8. Use one tool from a stacked tool pile and confirm the used item separates before durability changes.
9. Test shift-click, drag, hopper and crafting edge cases.

## Why there are codec mixins
Minecraft 26.3's persistent `ItemStack` codec uses an integer range of 1..99 for `count`; its network stream uses VarInt. Nabi Stacks raises the persistence limit so counts above 99 survive save/load.
